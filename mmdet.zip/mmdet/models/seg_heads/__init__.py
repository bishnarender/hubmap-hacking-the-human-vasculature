# Copyright (c) OpenMMLab. All rights reserved.
from .panoptic_fpn_head import PanopticFPNHead  # noqa: F401,F403
from .panoptic_fusion_heads import *  # noqa: F401,F403
